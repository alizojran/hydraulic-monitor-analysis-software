const http = require('node:http');
const net = require('node:net');
const { URL } = require('node:url');
const { WebSocketServer } = require('ws');

const config = require('./config');
const { HmasDatabase } = require('./db');
const {
  FrameDecoder,
  encodeFrame,
  normalizeAlarm,
  normalizeFft,
  validateHello,
} = require('./protocol');

const db = new HmasDatabase(config.databaseUrl);
const liveClients = new Set();

function json(res, status, payload) {
  const body = Buffer.from(JSON.stringify(payload), 'utf8');
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': body.length,
    'access-control-allow-origin': config.corsOrigin,
    'access-control-allow-methods': 'GET,POST,OPTIONS',
    'access-control-allow-headers': 'content-type,authorization',
  });
  res.end(body);
}

function parseLimit(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return config.historyLimit;
  return Math.min(Math.floor(n), config.historyLimit);
}

function parseDateParam(value) {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

function rowToLiveFft(row, spectrumDb = null) {
  return {
    type: 'fft',
    deviceId: row.device_id,
    seq: row.seq,
    ts: new Date(row.ts).getTime(),
    channelId: row.channel_id,
    sampleRate: row.sample_rate,
    fftSize: row.fft_size,
    binHz: row.bin_hz,
    rms: row.rms,
    peak: row.peak,
    crestFactor: row.crest_factor,
    thd: row.thd ?? 0,
    mainFreq: row.main_freq,
    mainAmpDb: row.main_amp_db,
    peaks: row.peaks ?? [],
    bearing: row.bearing ?? {},
    spectrumDb,
  };
}

function publicFftMessage(msg) {
  return {
    type: 'fft',
    deviceId: msg.deviceId,
    seq: msg.seq,
    ts: msg.ts.getTime(),
    channelId: msg.channelId,
    sampleRate: msg.sampleRate,
    fftSize: msg.fftSize,
    binHz: msg.binHz,
    rms: msg.rms,
    peak: msg.peak,
    crestFactor: msg.crestFactor,
    thd: msg.thd,
    mainFreq: msg.mainFreq,
    mainAmpDb: msg.mainAmpDb,
    peaks: msg.peaks,
    bearing: msg.bearing,
    spectrumDb: msg.spectrumDb,
    ch: msg.ch,
  };
}

function broadcast(payload) {
  const text = JSON.stringify(payload);
  for (const client of liveClients) {
    if (client.ws.readyState !== client.ws.OPEN) continue;
    if (client.deviceId && payload.deviceId && client.deviceId !== payload.deviceId) continue;
    client.ws.send(text);
  }
}

const httpServer = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    json(res, 204, {});
    return;
  }

  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (url.pathname === '/health') {
      json(res, 200, { ok: true, ts: Date.now() });
      return;
    }

    if (url.pathname === '/api/latest') {
      const deviceId = url.searchParams.get('deviceId') || config.deviceId;
      if (!deviceId) {
        json(res, 400, { error: 'deviceId is required' });
        return;
      }
      const rows = await db.latest(deviceId);
      json(res, 200, { deviceId, rows: rows.map((row) => rowToLiveFft(row)) });
      return;
    }

    if (url.pathname === '/api/history') {
      const deviceId = url.searchParams.get('deviceId') || config.deviceId;
      const channelId = url.searchParams.get('channelId');
      if (!deviceId) {
        json(res, 400, { error: 'deviceId is required' });
        return;
      }
      const rows = await db.history({
        deviceId,
        channelId,
        from: parseDateParam(url.searchParams.get('from')),
        to: parseDateParam(url.searchParams.get('to')),
        limit: parseLimit(url.searchParams.get('limit')),
      });
      json(res, 200, { deviceId, rows: rows.map((row) => rowToLiveFft(row)) });
      return;
    }

    if (url.pathname === '/api/spectrum') {
      const deviceId = url.searchParams.get('deviceId') || config.deviceId;
      const channelId = url.searchParams.get('channelId');
      if (!deviceId) {
        json(res, 400, { error: 'deviceId is required' });
        return;
      }
      const rows = await db.spectrum({
        deviceId,
        channelId,
        from: parseDateParam(url.searchParams.get('from')),
        to: parseDateParam(url.searchParams.get('to')),
        limit: parseLimit(url.searchParams.get('limit')),
      });
      json(res, 200, { deviceId, rows });
      return;
    }

    if (url.pathname === '/api/alarms') {
      const deviceId = url.searchParams.get('deviceId') || config.deviceId;
      if (!deviceId) {
        json(res, 400, { error: 'deviceId is required' });
        return;
      }
      const rows = await db.alarms({ deviceId, limit: parseLimit(url.searchParams.get('limit')) });
      json(res, 200, { deviceId, rows });
      return;
    }

    json(res, 404, { error: 'not found' });
  } catch (err) {
    console.error('[http]', err);
    json(res, 500, { error: String(err.message || err) });
  }
});

const wss = new WebSocketServer({ noServer: true });
wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const client = { ws, deviceId: url.searchParams.get('deviceId') || '' };
  liveClients.add(client);
  ws.send(JSON.stringify({ type: 'status', status: 'connected', ts: Date.now() }));
  ws.on('close', () => liveClients.delete(client));
});

httpServer.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname !== '/ws/live') {
    socket.destroy();
    return;
  }
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
});

function sendAck(socket, seq, status = 'ok') {
  if (seq === null || seq === undefined) return;
  socket.write(encodeFrame({ v: 1, type: 'ack', seq, status, ts: Date.now() }));
}

function startTcpServer() {
  const server = net.createServer((socket) => {
    const remoteAddr = `${socket.remoteAddress}:${socket.remotePort}`;
    const decoder = new FrameDecoder(config.maxFrameBytes);
    let authedDeviceId = '';

    socket.setKeepAlive(true, 30_000);
    socket.on('data', async (chunk) => {
      try {
        const frames = decoder.push(chunk);
        for (const frame of frames) {
          if (!authedDeviceId) {
            if (!validateHello(frame)) {
              socket.write(encodeFrame({ v: 1, type: 'error', error: 'hello required' }));
              socket.destroy();
              return;
            }
            const ok = await db.authenticateDevice(frame.deviceId, frame.secret);
            if (!ok) {
              await db.logIngest(frame.deviceId, remoteAddr, 'auth_failed');
              socket.write(encodeFrame({ v: 1, type: 'error', error: 'auth failed' }));
              socket.destroy();
              return;
            }
            authedDeviceId = frame.deviceId;
            await db.markOnline(authedDeviceId);
            await db.logIngest(authedDeviceId, remoteAddr, 'connected');
            socket.write(encodeFrame({ v: 1, type: 'hello_ack', deviceId: authedDeviceId, ts: Date.now() }));
            broadcast({ type: 'device_status', deviceId: authedDeviceId, status: 'online', ts: Date.now() });
            continue;
          }

          if (frame.deviceId && frame.deviceId !== authedDeviceId) {
            socket.write(encodeFrame({ v: 1, type: 'error', error: 'deviceId mismatch' }));
            continue;
          }

          if (frame.type === 'heartbeat') {
            await db.markOnline(authedDeviceId);
            sendAck(socket, frame.seq);
            broadcast({ type: 'heartbeat', deviceId: authedDeviceId, ts: Date.now(), payload: frame });
          } else if (frame.type === 'fft') {
            const msg = normalizeFft({ ...frame, deviceId: authedDeviceId });
            await db.insertFft(msg);
            sendAck(socket, msg.seq);
            broadcast(publicFftMessage(msg));
          } else if (frame.type === 'alarm') {
            const msg = normalizeAlarm({ ...frame, deviceId: authedDeviceId });
            await db.insertAlarm(msg);
            sendAck(socket, msg.seq);
            broadcast({
              type: 'alarm',
              deviceId: msg.deviceId,
              seq: msg.seq,
              ts: msg.ts.getTime(),
              channelId: msg.channelId,
              severity: msg.severity,
              message: msg.message,
              payload: msg.payload,
            });
          } else {
            socket.write(encodeFrame({ v: 1, type: 'error', error: `unsupported type ${frame.type}` }));
          }
        }
      } catch (err) {
        console.error('[tcp]', remoteAddr, err);
        await db.logIngest(authedDeviceId, remoteAddr, 'error', String(err.message || err)).catch(() => {});
        socket.write(encodeFrame({ v: 1, type: 'error', error: String(err.message || err) }));
        socket.destroy();
      }
    });

    socket.on('close', async () => {
      if (authedDeviceId) {
        await db.markOffline(authedDeviceId).catch(() => {});
        await db.logIngest(authedDeviceId, remoteAddr, 'disconnected').catch(() => {});
        broadcast({ type: 'device_status', deviceId: authedDeviceId, status: 'offline', ts: Date.now() });
      }
    });
  });

  server.listen(config.tcpPort, config.host, () => {
    console.log(`[tcp] listening on ${config.host}:${config.tcpPort}`);
  });
  return server;
}

async function bootstrapDevice() {
  if (!config.deviceId || !config.deviceSecret) return;
  await db.registerDevice(config.deviceId, config.deviceSecret, config.deviceId);
  console.log(`[db] bootstrap device ready: ${config.deviceId}`);
}

async function main() {
  await bootstrapDevice();
  startTcpServer();
  httpServer.listen(config.httpPort, config.host, () => {
    console.log(`[http] listening on http://${config.host}:${config.httpPort}`);
    console.log(`[ws] live endpoint ws://${config.host}:${config.httpPort}/ws/live`);
  });
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
