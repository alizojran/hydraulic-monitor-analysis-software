const crypto = require('node:crypto');
const { Pool } = require('pg');

function hashSecret(secret) {
  return crypto.createHash('sha256').update(secret, 'utf8').digest('hex');
}

class HmasDatabase {
  constructor(databaseUrl) {
    if (!databaseUrl) throw new Error('DATABASE_URL is required');
    this.pool = new Pool({ connectionString: databaseUrl });
  }

  async close() {
    await this.pool.end();
  }

  async registerDevice(id, secret, name = id) {
    const secretHash = hashSecret(secret);
    await this.pool.query(
      `INSERT INTO devices (id, name, secret_hash, status, last_seen_at)
       VALUES ($1, $2, $3, 'offline', now())
       ON CONFLICT (id) DO UPDATE
       SET name = EXCLUDED.name,
           secret_hash = EXCLUDED.secret_hash`,
      [id, name, secretHash],
    );
  }

  async authenticateDevice(id, secret) {
    const { rows } = await this.pool.query('SELECT secret_hash FROM devices WHERE id = $1', [id]);
    if (rows.length === 0) return false;
    return rows[0].secret_hash === hashSecret(secret);
  }

  async markOnline(id) {
    await this.pool.query(
      `UPDATE devices
       SET status = 'online', last_seen_at = now()
       WHERE id = $1`,
      [id],
    );
  }

  async markOffline(id) {
    if (!id) return;
    await this.pool.query(
      `UPDATE devices
       SET status = 'offline', last_seen_at = now()
       WHERE id = $1`,
      [id],
    );
  }

  async logIngest(deviceId, remoteAddr, event, detail = '') {
    await this.pool.query(
      `INSERT INTO device_ingest_log (device_id, remote_addr, event, detail)
       VALUES ($1, $2, $3, $4)`,
      [deviceId || null, remoteAddr || null, event, detail || null],
    );
  }

  async insertFft(msg) {
    await this.pool.query(
      `INSERT INTO fft_summary (
         ts, device_id, seq, channel_id, sample_rate, fft_size, bin_hz,
         rms, peak, crest_factor, thd, main_freq, main_amp_db,
         bpfi_hz, bpfi_db, bpfo_hz, bpfo_db, bsf_hz, bsf_db, ftf_hz, ftf_db,
         peaks, bearing
       )
       VALUES (
         $1, $2, $3, $4, $5, $6, $7,
         $8, $9, $10, $11, $12, $13,
         $14, $15, $16, $17, $18, $19, $20, $21,
         $22::jsonb, $23::jsonb
       )`,
      [
        msg.ts,
        msg.deviceId,
        msg.seq,
        msg.channelId,
        msg.sampleRate,
        msg.fftSize,
        msg.binHz,
        msg.rms,
        msg.peak,
        msg.crestFactor,
        msg.thd,
        msg.mainFreq,
        msg.mainAmpDb,
        msg.bpfiHz,
        msg.bpfiDb,
        msg.bpfoHz,
        msg.bpfoDb,
        msg.bsfHz,
        msg.bsfDb,
        msg.ftfHz,
        msg.ftfDb,
        JSON.stringify(msg.peaks),
        JSON.stringify(msg.bearing),
      ],
    );

    if (msg.spectrumDb && msg.spectrumDb.length > 0) {
      await this.pool.query(
        `INSERT INTO fft_spectrum (
           ts, device_id, seq, channel_id, sample_rate, fft_size, bin_hz, spectrum_db
         )
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb)`,
        [
          msg.ts,
          msg.deviceId,
          msg.seq,
          msg.channelId,
          msg.sampleRate,
          msg.fftSize,
          msg.binHz,
          JSON.stringify(msg.spectrumDb),
        ],
      );
    }
  }

  async insertAlarm(msg) {
    await this.pool.query(
      `INSERT INTO alarm_events (ts, device_id, seq, channel_id, severity, message, payload)
       VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb)`,
      [
        msg.ts,
        msg.deviceId,
        msg.seq,
        msg.channelId,
        msg.severity,
        msg.message,
        JSON.stringify(msg.payload),
      ],
    );
  }

  async latest(deviceId) {
    const { rows } = await this.pool.query(
      `SELECT DISTINCT ON (channel_id)
         ts, device_id, seq, channel_id, sample_rate, fft_size, bin_hz,
         rms, peak, crest_factor, thd, main_freq, main_amp_db,
         bpfi_hz, bpfi_db, bpfo_hz, bpfo_db, bsf_hz, bsf_db, ftf_hz, ftf_db,
         peaks, bearing
       FROM fft_summary
       WHERE device_id = $1
       ORDER BY channel_id, ts DESC`,
      [deviceId],
    );
    return rows;
  }

  async history({ deviceId, channelId, from, to, limit }) {
    const params = [deviceId, channelId, from, to, limit];
    const { rows } = await this.pool.query(
      `SELECT
         ts, device_id, seq, channel_id, sample_rate, fft_size, bin_hz,
         rms, peak, crest_factor, thd, main_freq, main_amp_db,
         bpfi_hz, bpfi_db, bpfo_hz, bpfo_db, bsf_hz, bsf_db, ftf_hz, ftf_db,
         peaks, bearing
       FROM fft_summary
       WHERE device_id = $1
         AND ($2::text IS NULL OR channel_id = $2)
         AND ($3::timestamptz IS NULL OR ts >= $3)
         AND ($4::timestamptz IS NULL OR ts <= $4)
       ORDER BY ts DESC
       LIMIT $5`,
      params,
    );
    return rows;
  }

  async spectrum({ deviceId, channelId, from, to, limit }) {
    const { rows } = await this.pool.query(
      `SELECT ts, device_id, seq, channel_id, sample_rate, fft_size, bin_hz, spectrum_db
       FROM fft_spectrum
       WHERE device_id = $1
         AND ($2::text IS NULL OR channel_id = $2)
         AND ($3::timestamptz IS NULL OR ts >= $3)
         AND ($4::timestamptz IS NULL OR ts <= $4)
       ORDER BY ts DESC
       LIMIT $5`,
      [deviceId, channelId, from, to, limit],
    );
    return rows;
  }

  async alarms({ deviceId, limit }) {
    const { rows } = await this.pool.query(
      `SELECT id, ts, device_id, seq, channel_id, severity, message, payload
       FROM alarm_events
       WHERE device_id = $1
       ORDER BY ts DESC
       LIMIT $2`,
      [deviceId, limit],
    );
    return rows;
  }
}

module.exports = { HmasDatabase, hashSecret };
