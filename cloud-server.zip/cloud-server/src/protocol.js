const { TextDecoder } = require('node:util');

const decoder = new TextDecoder();

function encodeFrame(payload) {
  const body = Buffer.from(JSON.stringify(payload), 'utf8');
  const head = Buffer.allocUnsafe(4);
  head.writeUInt32BE(body.length, 0);
  return Buffer.concat([head, body]);
}

class FrameDecoder {
  constructor(maxFrameBytes) {
    this.maxFrameBytes = maxFrameBytes;
    this.buffer = Buffer.alloc(0);
  }

  push(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    const frames = [];

    while (this.buffer.length >= 4) {
      const len = this.buffer.readUInt32BE(0);
      if (len <= 0 || len > this.maxFrameBytes) {
        throw new Error(`Invalid TCP frame length: ${len}`);
      }
      if (this.buffer.length < 4 + len) break;

      const body = this.buffer.subarray(4, 4 + len);
      this.buffer = this.buffer.subarray(4 + len);
      const text = decoder.decode(body);
      frames.push(JSON.parse(text));
    }

    return frames;
  }
}

function normalizeTimestamp(ts) {
  if (typeof ts === 'number' && Number.isFinite(ts)) {
    return new Date(ts > 10_000_000_000 ? ts : ts * 1000);
  }
  if (typeof ts === 'string') {
    const d = new Date(ts);
    if (!Number.isNaN(d.getTime())) return d;
  }
  return new Date();
}

function finiteNumber(value, fallback = null) {
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
}

function normalizePeak(p, idx, binHz) {
  const frequency = finiteNumber(p.frequency, finiteNumber(p.f, null));
  const amplitudeDb = finiteNumber(p.amplitudeDb, finiteNumber(p.db, null));
  if (frequency === null || amplitudeDb === null) return null;
  return {
    frequency,
    amplitudeDb,
    binIndex: Number.isInteger(p.binIndex) ? p.binIndex : Math.round(frequency / binHz),
    rank: idx + 1,
  };
}

function validateHello(msg) {
  if (msg.type !== 'hello') return false;
  return typeof msg.deviceId === 'string' && typeof msg.secret === 'string';
}

function normalizeFft(msg) {
  if (msg.type !== 'fft') throw new Error('Not an fft message');
  const deviceId = String(msg.deviceId ?? '');
  const channelId = String(msg.channelId ?? '');
  const sampleRate = finiteNumber(msg.sampleRate, null);
  const fftSize = finiteNumber(msg.fftSize, null);
  const binHz = finiteNumber(msg.binHz, sampleRate && fftSize ? sampleRate / fftSize : null);
  if (!deviceId || !channelId || !sampleRate || !fftSize || !binHz) {
    throw new Error('FFT message missing required deviceId/channelId/sampleRate/fftSize/binHz');
  }

  const peaks = Array.isArray(msg.peaks)
    ? msg.peaks.map((p, idx) => normalizePeak(p, idx, binHz)).filter(Boolean)
    : [];

  const bearing = msg.bearing && typeof msg.bearing === 'object' ? msg.bearing : {};
  const firstPeak = peaks[0] ?? null;

  return {
    type: 'fft',
    deviceId,
    seq: Number.isFinite(Number(msg.seq)) ? Number(msg.seq) : null,
    ts: normalizeTimestamp(msg.ts),
    channelId,
    sampleRate: Math.round(sampleRate),
    fftSize: Math.round(fftSize),
    binHz,
    rms: finiteNumber(msg.rms, null),
    peak: finiteNumber(msg.peak, finiteNumber(msg.peakValue, null)),
    crestFactor: finiteNumber(msg.crestFactor, null),
    thd: finiteNumber(msg.thd, 0),
    mainFreq: firstPeak?.frequency ?? null,
    mainAmpDb: firstPeak?.amplitudeDb ?? null,
    peaks,
    bearing,
    bpfiHz: finiteNumber(bearing.bpfiHz, finiteNumber(bearing.bpfi, null)),
    bpfiDb: finiteNumber(bearing.bpfiDb, null),
    bpfoHz: finiteNumber(bearing.bpfoHz, finiteNumber(bearing.bpfo, null)),
    bpfoDb: finiteNumber(bearing.bpfoDb, null),
    bsfHz: finiteNumber(bearing.bsfHz, finiteNumber(bearing.bsf, null)),
    bsfDb: finiteNumber(bearing.bsfDb, null),
    ftfHz: finiteNumber(bearing.ftfHz, finiteNumber(bearing.ftf, null)),
    ftfDb: finiteNumber(bearing.ftfDb, null),
    spectrumDb: Array.isArray(msg.spectrumDb) ? msg.spectrumDb.map((v) => finiteNumber(v, -120)) : null,
    ch: msg.ch && typeof msg.ch === 'object' ? msg.ch : null,
  };
}

function normalizeAlarm(msg) {
  if (msg.type !== 'alarm') throw new Error('Not an alarm message');
  return {
    type: 'alarm',
    deviceId: String(msg.deviceId ?? ''),
    seq: Number.isFinite(Number(msg.seq)) ? Number(msg.seq) : null,
    ts: normalizeTimestamp(msg.ts),
    channelId: typeof msg.channelId === 'string' ? msg.channelId : null,
    severity: typeof msg.severity === 'string' ? msg.severity : 'info',
    message: typeof msg.message === 'string' ? msg.message : '',
    payload: msg,
  };
}

module.exports = {
  FrameDecoder,
  encodeFrame,
  normalizeTimestamp,
  validateHello,
  normalizeFft,
  normalizeAlarm,
};
