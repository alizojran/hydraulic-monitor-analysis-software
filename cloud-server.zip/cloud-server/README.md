# HMAS Cloud Server

Cloud-side service for the HMAS TCP architecture:

- TCP Server: receives CODESYS length-prefixed JSON frames.
- Authentication: `hello` frame validates `deviceId` and `secret`.
- PostgreSQL/TimescaleDB storage: FFT summary, full spectrum, alarms.
- HTTP API: latest values and history queries for the local Vue/HTML client.
- WebSocket relay: pushes live FFT/alarm/status frames to the browser.

## Quick Start

```bash
cd cloud-server
npm install
cp .env.example .env
# edit DATABASE_URL, DEVICE_ID, DEVICE_SECRET
psql "$DATABASE_URL" -f sql/schema.sql
npm run register-device
npm start
```

Default ports:

- TCP ingest: `9100`
- HTTP API: `8080`
- WebSocket live: `ws://<server>:8080/ws/live?deviceId=HMAS-001`

## CODESYS TCP Frame

Each TCP message is:

```text
[4-byte big-endian JSON length][JSON payload]
```

`hello`:

```json
{
  "v": 1,
  "type": "hello",
  "deviceId": "HMAS-001",
  "secret": "change-this-device-secret",
  "ts": 1719300000000
}
```

`fft`:

```json
{
  "v": 1,
  "type": "fft",
  "deviceId": "HMAS-001",
  "seq": 1024,
  "ts": 1719300000000,
  "channelId": "V02",
  "sampleRate": 10000,
  "fftSize": 2048,
  "binHz": 4.8828125,
  "rms": 0.42,
  "peak": 1.16,
  "crestFactor": 2.76,
  "peaks": [{ "f": 25.4, "db": -12.6 }],
  "bearing": { "bpfiHz": 135.2, "bpfiDb": -24.1, "bpfoHz": 89.7, "bpfoDb": -31.5 },
  "spectrumDb": [-80.1, -78.2, -75.4]
}
```

## HTTP API

```text
GET /health
GET /api/latest?deviceId=HMAS-001
GET /api/history?deviceId=HMAS-001&channelId=V02&from=2026-06-26T00:00:00Z&to=2026-06-27T00:00:00Z&limit=1000
GET /api/spectrum?deviceId=HMAS-001&channelId=V02&limit=100
GET /api/alarms?deviceId=HMAS-001&limit=100
```

## Notes

- Periodic FFT data can use best-effort delivery. The `seq` field lets the
  server and UI detect gaps.
- Full spectrum JSON is convenient for the first version. Once the link is
  stable, change `spectrum_db` to compressed `bytea` if storage becomes large.
